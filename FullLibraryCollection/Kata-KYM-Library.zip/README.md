# Kata KYM Library

## Overview
Collection of Kyma Kata community project files for use with [Symbolic Sound Kyma](https://kyma.symbolicsound.com) system.

## Additional Information 

Kyma Kata is a user community open to anyone using SSC’s Kyma systems.  Kyma Kata is focused on learning and sharing of ideas, techniques, and often undertakes projects to create new prototypes and library examples.  

Files are shared openly and freely.  Files and prototypes may not be repackaged and sold commercially (though can and should be used to produce creative work).

